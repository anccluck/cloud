document.addEventListener('DOMContentLoaded', function() {
  var usernameInput = document.getElementById('username');
  var passwordInput = document.getElementById('password');
  var registerForm = document.getElementById('register-form');
  var registerBtn = document.getElementById('register-btn');
  var usernameError = document.getElementById('username-error');
  var passwordError = document.getElementById('password-error');

  usernameInput.addEventListener('input', function() {
    // 아이디 중복 검사 코드 추가
    // ...
  });

  passwordInput.addEventListener('input', function() {
    // 비밀번호 길이 검사 코드 추가
    if (passwordInput.value.length < 8) {
      passwordError.textContent = '비밀번호는 8자 이상이어야 합니다.';
      registerBtn.disabled = true;
    } else {
      passwordError.textContent = '';
      registerBtn.disabled = false;
    }
  });

  registerForm.addEventListener('submit', function(event) {
    event.preventDefault();
    // 회원가입 처리 코드 추가
    // ...
  });
});

