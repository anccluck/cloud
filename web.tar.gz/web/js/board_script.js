// board_script.js

// 드롭다운 메뉴 표시/숨기기 함수
function toggleDropdown(event) {
  var dropdownMenu = this.querySelector('.dropdown-menu');
  if (dropdownMenu.style.display === 'none' || dropdownMenu.style.display === '') {
    dropdownMenu.style.display = 'block';
  } else {
    dropdownMenu.style.display = 'none';
  }
}

// 게시판 메뉴에 마우스 올리면 드롭다운 메뉴 표시
var boardMenu = document.querySelector('nav li:nth-child(2) > a.dropdown-toggle');
boardMenu.addEventListener('click', toggleDropdown);

