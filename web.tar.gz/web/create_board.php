<?php
include 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>게시물 작성</title>
    <link rel="stylesheet" href="css/create_board_style.css">
</head>
<body class="board-create">
    <div class="board">
        <h1>게시물 작성</h1>
        <form method="post" action="save_board_process.php">
            <div>
                <label for="title">제목:</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div>
                <label for="content">내용:</label>
                <textarea id="content" name="content" rows="5" required></textarea>
            </div>
            <button type="submit">저장</button>
        </form>
    </div>
</body>
</html>

