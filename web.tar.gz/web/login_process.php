<?php
session_start();
require_once 'setup/db_connect.php';

$username = $_POST['username'];
$password = $_POST['password'];

if (empty($username) || empty($password)) {
    echo "<script>alert('아이디와 비밀번호를 입력해 주세요.'); window.location.href = 'login.php';</script>";
    exit;
}

$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($password, $user['password'])) {
    $_SESSION["user_id"] = $username;
    # SESSION["nickname"] = $;
    // 디버깅: 세션 변수 값 확인
   # var_dump($_SESSION["username"]); // 출력 결과 확인

    echo "<script>alert('로그인 되었습니다.'); window.location.href = '/';</script>";
} else {
    echo "<script>alert('아이디 또는 비밀번호가 잘못되었습니다.'); window.location.href = 'login.php';</script>";
}

$stmt->close();
$conn->close();
?>
