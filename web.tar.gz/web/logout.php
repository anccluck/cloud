<?php
// 세션 시작
session_start();

// 세션 파괴
session_destroy();

echo "<script>alert('로그아웃 되었습니다.'); window.location.href = '/';</script>";

?>

