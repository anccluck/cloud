<?php
session_start();
include 'header.php';
include 'setup/db_connect.php';

// 게시물 ID 가져오기
if (!isset($_GET['id'])) {
    echo "게시물 ID가 전달되지 않았습니다.";
    exit;
}

$post_id = $_GET['id'];

// 게시물 정보 조회 쿼리
$sql = "SELECT * FROM questions WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $post = $result->fetch_assoc();

    // 현재 로그인한 사용자 ID 가져오기
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $post['title']; ?></title>
    <link rel="stylesheet" href="css/view_board_style.css">
</head>
<body>
    <div class="view-board">
        <div class="board-info">
            <h1><?php echo $post['title']; ?></h1>
            <div class="post-info">
                작성자: <?php echo $post['author']; ?> | 작성일: <?php echo $post['created_at']; ?> | 수정일: <?php echo $post['updated_at']; ?>
            </div>
            <div class="post-content"><?php echo nl2br($post['content']); ?></div>

            <?php if ($user_id == $post['author']) { ?>
                <div class="post-actions">
                    <button type="button" class="delete-btn" onclick="location.href='delete_free_board.php?id=<?php echo $post['id']; ?>'">삭제</button>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>
<?php
} else {
    echo "해당 게시물을 찾을 수 없습니다.";
}

$stmt->close();
$conn->close();
?>

