<?php
require_once 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>회원가입</title>
    <link rel="stylesheet" href="css/register_style.css">
    <script>
        function validateForm() {
            let isValid = true;

            // 아이디 유효성 검사
            const usernameInput = document.getElementById('username');
            const usernameError = document.getElementById('username-error');
            if (!usernameInput.value.match(/^[a-zA-Z0-9]+$/)) {
                usernameError.textContent = '아이디는 영문과 숫자만 사용 가능합니다.';
                isValid = false;
            } else {
                usernameError.textContent = '';
            }

            // 닉네임 유효성 검사
            const nicknameInput = document.getElementById('nickname');
            const nicknameError = document.getElementById('nickname-error');
            if (!nicknameInput.value.match(/^[a-zA-Z가-힣0-9]+$/)) {
                nicknameError.textContent = '특수기호는 사용 불가합니다.';
                isValid = false;
            } else {
                nicknameError.textContent = '';
            }

            // 이메일 유효성 검사
            const emailInput = document.getElementById('email');
            const emailError = document.getElementById('email-error');
            if (!emailInput.value.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)) {
                emailError.textContent = '유효한 이메일 주소를 입력해 주세요.';
                isValid = false;
            } else {
                emailError.textContent = '';
            }

            // 비밀번호 유효성 검사
            const passwordInput = document.getElementById('password');
            const passwordError = document.getElementById('password-error');
            if (passwordInput.value.length < 8) {
                passwordError.textContent = '비밀번호는 최소 8자 이상이어야 합니다.';
                isValid = false;
            } else {
                passwordError.textContent = '';
            }

            // 비밀번호 확인 검사
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const confirmPasswordError = document.getElementById('confirm-password-error');
            if (passwordInput.value !== confirmPasswordInput.value) {
                confirmPasswordError.textContent = '비밀번호가 일치하지 않습니다.';
                isValid = false;
            } else {
                confirmPasswordError.textContent = '';
            }

            return isValid;
        }
    </script>
</head>
<body>
    <div class="register-container">
        <div class="register-form">
            <h2>회원가입</h2>
            <form action="register_process.php" method="post" onsubmit="return validateForm()">
                <label for="username">아이디:</label>
                <input type="text" id="username" name="username" required>
                <span class="error-message" id="username-error"></span>

                <label for="nickname">닉네임:</label>
                <input type="text" id="nickname" name="nickname" required>
                <span class="error-message" id="nickname-error"></span>

                <label for="email">이메일:</label>
                <input type="email" id="email" name="email" required>
                <span class="error-message" id="email-error"></span>

                <label for="password">비밀번호:</label>
                <input type="password" id="password" name="password" minlength="8" required>
                <span class="error-message" id="password-error"></span>

                <label for="confirmPassword">비밀번호 확인:</label>
                <input type="password" id="confirmPassword" name="confirmPassword" minlength="8" required>
                <span class="error-message" id="confirm-password-error"></span>

                <button type="submit">회원가입</button>
            </form>
        </div>
    </div>
</body>
</html>

