<?php
// DB 연결 정보
$servername = "localhost";
$username = "webadmin";
$password = "pwadmin";
$dbname = "webdb";

// DB 연결
$conn = new mysqli($servername, $username, $password, $dbname);

// 연결 확인
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

