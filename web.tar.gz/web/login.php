<?php
// 세션 시작
session_start();

// 세션 확인
if (isset($_SESSION['username'])) {
    header("Location: /index.php");
    exit;
}

require_once 'header.php';
?>



<link rel="stylesheet" href="css/login_style.css">
<div class="login-container">
  <div class="login-form">
    <h2>로그인</h2>
    <form method="post" action="login_process.php">
      <label for="username">아이디:</label>
      <input type="text" id="username" name="username" required>
      <label for="password">비밀번호:</label>
      <input type="password" id="password" name="password" required>
      <button type="submit">로그인</button>
    </form>
  </div>
</div>

