<?php
session_start();
include 'setup/db_connect.php';

// 게시물 ID 가져오기
if (!isset($_GET['id'])) {
    echo "게시물 ID가 전달되지 않았습니다.";
    exit;
}

$post_id = $_GET['id'];

// 현재 로그인한 사용자 ID 가져오기
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// 게시물 존재 여부 확인
$sql_select = "SELECT author FROM questions WHERE id = ?";
$stmt_select = $conn->prepare($sql_select);
$stmt_select->bind_param("i", $post_id);
$stmt_select->execute();
$result_select = $stmt_select->get_result();

if ($result_select->num_rows > 0) {
    $row = $result_select->fetch_assoc();
    $author_id = $row['author'];

    // 현재 사용자가 게시물의 작성자인지 확인
    if ($user_id == $author_id) {
        // 게시물 삭제 쿼리
        $sql_delete = "DELETE FROM questions WHERE id = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $post_id);
        
        if ($stmt_delete->execute()) {
            // 삭제 성공 시 메시지 출력 또는 리다이렉션
            echo "게시물이 성공적으로 삭제되었습니다.";
            // 예: 삭제 후 메인 페이지로 리다이렉션
            header("Location: free_board.php");
            exit;
        } else {
            echo "게시물 삭제 중 오류가 발생했습니다.";
        }
    } else {
        echo "게시물을 삭제할 권한이 없습니다.";
    }
} else {
    echo "해당 게시물을 찾을 수 없습니다.";
}

$stmt_select->close();
$stmt_delete->close();
$conn->close();
?>

