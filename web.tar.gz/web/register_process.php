<?php
// DB 연결 파일 포함
require_once 'setup/db_connect.php';

// 회원가입 폼 데이터 받기
$username = $_POST['username'];
$nickname = $_POST['nickname'];
$email = $_POST['email'];
$password = $_POST['password'];

// 유효성 검사
if (empty($username) || empty($nickname) || empty($email) || empty($password)) {
    echo "<script>alert('모든 필드를 입력해 주세요.'); window.location.href = 'register.php';</script>";
    exit;
}

if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
    echo "<script>alert('아이디는 영문과 숫자만 사용 가능합니다.'); window.location.href = 'register.php';</script>";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<script>alert('유효한 이메일 주소를 입력해 주세요.'); window.location.href = 'register.php';</script>";
    exit;
}

// 닉네임 유효성 검사 (영문과 한글만 허용)
if (!preg_match('/^[a-zA-Z가-힣0-9]+$/', $nickname)) {
    echo "<script>alert('특수기호는 사용이 불가합니다.'); window.location.href = 'register.php';</script>";
    exit;
}

// 비밀번호 암호화
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// 사용자 정보 DB에 저장
$sql = "INSERT INTO users (username, nickname, email, password) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $username, $nickname, $email, $hashed_password);

if ($stmt->execute()) {
    echo "<script>alert('회원가입이 완료되었습니다. 로그인 페이지로 이동합니다.'); window.location.href = 'login.php';</script>";
} else {
    echo "<script>alert('회원가입에 실패했습니다. 다시 시도해 주세요.'); window.location.href = 'register.php';</script>";
}

$stmt->close();
$conn->close();
?>

