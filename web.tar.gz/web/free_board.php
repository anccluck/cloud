<?php
session_start();
include 'header.php'; // 헤더 파일 인클루드

// DB 연결 파일 인클루드
include 'setup/db_connect.php';

// 공지사항 목록 쿼리
$sql = "SELECT id, title, author, created_at FROM questions ORDER BY created_at DESC";
$result = $conn->query($sql);

// DB 연결 종료
$conn->close();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>자유게시판</title>
    <link rel="stylesheet" href="css/board_style.css">
</head>
<body>
    <div class="board">
        <h1>자유게시판</h1>
        <table>
            <thead>
                <tr>
                    <th>번호</th>
                    <th>제목</th>
                    <th>작성자</th>
                    <th>작성일</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // 공지사항 목록 출력
                if ($result->num_rows > 0) {
                    $num = 1;
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $num . "</td>";
                        echo "<td><a href='view_free_board.php?id=" . $row["id"] . "'>" . $row["title"] . "</a></td>";
                        echo "<td>" . $row["author"] . "</td>";
                        echo "<td>" . $row["created_at"] . "</td>";
                        echo "</tr>";
                        $num++;
                    }
                } else {
                    echo "<tr><td colspan='4'>게시물이 없습니다.</td></tr>";
                }
                ?>
            </tbody>
        </table>
	<?php
	
	if (isset($_SESSION['user_id'])) {
	    echo "<button type='button' class='btn' onclick=\"window.location.href='create_free_board.php'\">게시물 등록</button>";
	}	
	?>
        </div>
    </div>
</body>
</html>

