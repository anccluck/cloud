<?php
    // 세션 시작
    session_start();

    // 데이터베이스 연결 include
    include 'setup/db_connect.php';

    // 게시물 정보 가져오기
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_SESSION['user_id'];

    // 현재 날짜 및 시간 가져오기
    $created_at = date('Y-m-d H:i:s');
    $updated_at = $created_at;

    // 게시물 저장 쿼리 작성
    $sql = "INSERT INTO questions (title, content, author, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $title, $content, $author, $created_at, $updated_at);

    if ($stmt->execute()) {
        // 게시물 저장 성공 시 리다이렉트
        header("Location: free_board.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
    $conn->close();
?>

