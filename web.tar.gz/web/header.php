<?php
session_start();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/hstyle.css">
</head>
<body>
  <div class="container">
    <header>
      <div class="logo">
        <?php
            echo '<a href="/">AntRental</a>';
        ?>
      </div>
      <nav>
        <ul>
          <li><a>소개</a></li>
	<?php
            echo '<div class="dropdown">
                    <a class="login">게시판</a>
                    <div class="dropdown-content">
                      <a href="board.php">공지사항</a>
                      <a href="free_board.php">자유게시판</a>
                    </div>
                  </div>';
	?>
        </ul>
      </nav>
      <div class="user-actions">
        <?php
          if (isset($_SESSION['user_id'])) {
            echo '<div class="dropdown">
                    <a class="login">MY</a>
                    <div class="dropdown-content">
                      <a href="mypage.php">내 정보</a>
                      <a href="logout.php">로그아웃</a>
                    </div>
                  </div>';
          } else {
            echo '<div class="dropdown">
                    <a class="login">MY</a>
                    <div class="dropdown-content">
                      <a href="login.php">로그인</a>
                      <a href="register.php">회원가입</a>
                    </div>
                  </div>';
          }
        ?>
      </div>
    </header>
  </div>
</body>
</html>
